﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace Application;

delegate double Counter();

class Ingredient
{
    public string Name { get; set; } = string.Empty;
    public string Quantity { get; set; } = string.Empty;
    public string Measure { get; set; } = string.Empty;
    public string Calories { get; set; } = string.Empty;
    public string FoodGroup { get; set; } = string.Empty;
    string[] errors = new string[3];

    public Ingredient()
    {
    }

    public Ingredient(Ingredient obj)
    {
        this.Name = obj.Name;
        this.Quantity = obj.Quantity;
        this.Measure = obj.Measure;
        this.Calories = obj.Calories;
        this.FoodGroup = obj.FoodGroup;
    }

    public void ScaleByFactor(double factor)
    {
        string words = string.Empty;
        ulong qty = WordsToNumbers(this.Quantity);
        if (qty == 0)
        {
            double wordNumber;
            if (Double.TryParse(this.Quantity, out wordNumber))
            {
                words = NumberToWords(wordNumber * factor);
            }
        }
        else
        {
            words = NumberToWords(qty * factor);
        }

        double val;
        if (Double.TryParse(this.Quantity, out val))
        {
            if (Double.TryParse(words, out val))
            {
                this.Quantity = "" + val + "";
            }
            else
            {
                this.Quantity = "" + Convert.ToInt64(WordsToNumbers(words)) + "";
            }
        }
        else
        {
            this.Quantity = words;
        }

        words = string.Empty;
        ulong calos = WordsToNumbers(this.Calories);
        if (calos == 0)
        {
            double wordNumber;
            if (Double.TryParse(this.Calories, out wordNumber))
            {
                words = NumberToWords(wordNumber * factor);
            }
        }
        else
        {
            words = NumberToWords(calos * factor);
        }

        double valCalos;
        if (Double.TryParse(this.Calories, out valCalos))
        {
            if (Double.TryParse(words, out valCalos))
            {
                this.Calories = "" + valCalos + "";
            }
            else
            {
                this.Calories = "" + Convert.ToInt64(WordsToNumbers(words)) + "";
            }
        }
        else
        {
            this.Calories = words;
        }
    }

    public static ulong WordsToNumbers(string words)
    {
        ulong val;
        if (ulong.TryParse(words, out val)) return (ulong)(val);

        if (string.IsNullOrEmpty(words)) return 0;

        words = words.Trim();
        words += ' ';

        ulong number = 0;
        string[] singles = new string[] { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
        string[] teens = new string[] { "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen" };
        string[] tens = new string[] { "", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninty" };
        string[] powers = new string[] { "", "thousand", "million", "billion", "trillion", "quadrillion", "quintillion" };

        for (int i = powers.Length - 1; i >= 0; i--)
        {
            if (!string.IsNullOrEmpty(powers[i]))
            {
                int index = words.IndexOf(powers[i]);

                if (index >= 0 && words[index + powers[i].Length] == ' ')
                {
                    ulong count = WordsToNumbers(words.Substring(0, index));
                    number += count * (ulong)Math.Pow(1000, i);
                    words = words.Remove(0, index);
                }
            }
        }

        {
            int index = words.IndexOf("hundred");

            if (index >= 0 && words[index + "hundred".Length] == ' ')
            {
                ulong count = WordsToNumbers(words.Substring(0, index));
                number += count * 100;
                words = words.Remove(0, index);
            }
        }

        for (int i = tens.Length - 1; i >= 0; i--)
        {
            if (!string.IsNullOrEmpty(tens[i]))
            {
                int index = words.IndexOf(tens[i]);

                if (index >= 0 && words[index + tens[i].Length] == ' ')
                {
                    number += (uint)(i * 10);
                    words = words.Remove(0, index);
                }
            }
        }

        for (int i = teens.Length - 1; i >= 0; i--)
        {
            if (!string.IsNullOrEmpty(teens[i]))
            {
                int index = words.IndexOf(teens[i]);

                if (index >= 0 && words[index + teens[i].Length] == ' ')
                {
                    number += (uint)(i + 10);
                    words = words.Remove(0, index);
                }
            }
        }

        for (int i = singles.Length - 1; i >= 0; i--)
        {
            if (!string.IsNullOrEmpty(singles[i]))
            {
                int index = words.IndexOf(singles[i] + ' ');

                if (index >= 0 && words[index + singles[i].Length] == ' ')
                {
                    number += (uint)(i);
                    words = words.Remove(0, index);
                }
            }
        }

        return number;
    }

    public static string NumberToWords(double value)
    {
        int number = (int)value;
        double decimalPoint = value - (int)value;

        if (number == 0)
            return "" + decimalPoint + "";

        if (number < 0)
            return "minus " + NumberToWords(Math.Abs(number));

        string words = "";

        if ((number / 1000000) > 0)
        {
            words += NumberToWords(number / 1000000) + " million ";
            number %= 1000000;
        }

        if ((number / 1000) > 0)
        {
            words += NumberToWords(number / 1000) + " thousand ";
            number %= 1000;
        }

        if ((number / 100) > 0)
        {
            words += NumberToWords(number / 100) + " hundred ";
            number %= 100;
        }

        if (number > 0)
        {
            if (words != "")
                words += "and ";

            var unitsMap = new[] { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen" };
            var tensMap = new[] { "zero", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety" };

            if (number < 20)
                words += unitsMap[number];
            else
            {
                words += tensMap[number / 10];
                if ((number % 10) > 0)
                    words += "-" + unitsMap[number % 10];
            }
        }

        if (number > 0 && decimalPoint > 0) return "" + value + "";

        return words;
    }

    public override string ToString()
    {
        return this.Quantity + " " + this.Measure + " of " + this.Name + " with " + this.Calories + " calories. " + "(Food Group = " + this.FoodGroup + ")";
    }

    public bool IsValid()
    {
        bool valid = true;

        if (WordsToNumbers(this.Quantity) < 1)
        {
            this.errors[0] = "Invalid Quantity: " + this.Quantity + ". Quantity must be a number. e.g 15, 100, twelve or one hundred";
            valid = false;
        }
        if (string.IsNullOrEmpty(this.Name))
        {
            this.errors[1] = "Invalid Name: " + this.Name + ". Name cannot be null or empty.";
            valid = false;
        }
        if (string.IsNullOrEmpty(this.Measure))
        {
            this.errors[2] = "Invalid unit of measurement: " + this.Measure + ". Unit of measurement cannot be empty.";
            valid = false;
        }

        return valid;
    }

    public string getErrors()
    {
        string erros = string.Empty;
        erros += String.Join('\n', this.errors);
        return erros;
    }
}

class Recipe
{

    public string Name;
    public List<Ingredient> initialIngredients = new List<Ingredient>();
    public List<Ingredient> Ingredients;
    public List<string> Steps;

    public Recipe()
    {
        this.Name = string.Empty;
        this.Ingredients = new List<Ingredient>();
        this.Steps = new List<string>();
    }

    public Recipe(string name, List<Ingredient> ingredients, List<String> steps)
    {
        this.Name = name;
        this.Ingredients = ingredients;
        this.initialIngredients = ingredients.ConvertAll(x => new Ingredient(x));
        this.Steps = steps;
    }

    public void Reset()
    {
        this.Ingredients = this.initialIngredients;
    }

    public override string ToString()
    {

        string recipeString = "Recipe Information:\n";
        recipeString += "------------------------\n";

        recipeString += "Ingredients:\n";
        for (int i = 0; i < this.Ingredients.Count; i++)
        {
            Console.WriteLine(this.Ingredients.Count);
            int s = i + 1;
            recipeString += s + ". " + this.Ingredients[i] + "\n";
        }
        recipeString += "Steps:\n";
        for (int i = 0; i < this.Steps.Count; i++)
        {
            Console.WriteLine(this.Steps.Count);
            int s = i + 1;
            recipeString += s + ". " + this.Steps[i] + "\n";
        }
        return recipeString;
    }

    public void ScaleByFactor(double factor)
    {
        foreach (var ingredient in this.Ingredients)
        {
            ingredient.ScaleByFactor(factor);
        }

        Console.WriteLine("Recipe successfully updated");
        Console.WriteLine("------------------------\n");
    }

    public double CaloriesCounter()
    {
        double caloriesSum = 0;
        foreach (var ingredient in this.Ingredients)
        {
            caloriesSum += Ingredient.WordsToNumbers(ingredient.Calories);
        }
        return caloriesSum;
    }
}

public class Program
{

    public static void Main(string[] args)
    {
        Console.WriteLine("Console Recipe App in C#\r");
        Console.WriteLine("------------------------\n");
        List<Recipe> recipeList = new List<Recipe>();

        string value = "";
        string level2Value = "";
        do
        {
            Console.Write("Current Recipes:\n");
            if (recipeList.Count > 0)
            {
                List<Recipe> sortedRecipeList = recipeList.OrderBy(aRecipe => aRecipe.Name).ToList();
                foreach (Recipe aRecipe in sortedRecipeList)
                {
                    Console.WriteLine(aRecipe.Name);
                }
                Console.WriteLine();
            }
            Console.WriteLine("There's currently " + recipeList.Count + " recipes in the store.\n");

            Console.Write("Select Option Below:\n");
            Console.Write("[ ccr ] : Create New Recipe.\n");
            Console.Write("[ ssr ] : Select Recipe.\n");
            string selection = Console.ReadLine();

            if (selection == "ccr")
            {
                Console.WriteLine("Create New Recipe:\r");
                Console.WriteLine("------------------------\n");

                int count = 0;

                // Ask the user to type the first recipe name.
                Console.WriteLine("Type the recipe name, and then press Enter");
                string recipeName = Console.ReadLine();

                Console.WriteLine("Recipe Ingredient:\r");
                Console.WriteLine("------------------------\n");
                Console.WriteLine("How many ingredients does the recipe have? Type response, and then press Enter");
                count = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("------------------------\n");

                Console.WriteLine("For each ingredient, you are required to provide the name, quantity, and unit of measurement. \nFor example, one hundrend grams of milk\n");

                // Ask the user to type the ingredients info.
                List<Ingredient> recipeIngredients = new List<Ingredient>();

                for (int i = 1; i <= count; i++)
                {
                    bool entryAccepted = false;
                    Ingredient ingredient = new Ingredient();
                    while (entryAccepted == false)
                    {
                        Console.WriteLine("Ingrendient: " + i);
                        Console.WriteLine("------------------------\n");
                        Console.WriteLine("Type the name of ingredient, and then press Enter");
                        string name = Console.ReadLine();
                        ingredient.Name = name;
                        Console.WriteLine("Type the quantity value for ingredient: " + ingredient.Name + ", and then press Enter. For example, one hundred or 100");
                        string quantity = Console.ReadLine();
                        ingredient.Quantity = quantity;
                        Console.WriteLine("Type the unit of measurement for ingredient: " + ingredient.Name + ", and then press Enter. For example, grams");
                        string measure = Console.ReadLine();
                        ingredient.Measure = measure;
                        Console.WriteLine("Type the number of calories for ingredient: " + ingredient.Name + ", and then press Enter. For example, grams");
                        string calories = Console.ReadLine();
                        ingredient.Calories = calories;
                        Console.WriteLine("Type the food group name that the ingredient: " + ingredient.Name + " belongs to, and then press Enter. For example, grams");
                        string foodGroup = Console.ReadLine();
                        ingredient.FoodGroup = foodGroup;
                        entryAccepted = ingredient.IsValid();
                        if (entryAccepted == false)
                        {
                            Console.WriteLine("\n");
                            Console.WriteLine("Errors!");
                            Console.WriteLine(ingredient.getErrors());
                        }
                    }
                    recipeIngredients.Add(ingredient);
                    Console.WriteLine("\n");

                }
                // Ask the user to type the steps info.
                Console.WriteLine("Recipe Steps:\r");
                Console.WriteLine("------------------------\n");
                Console.WriteLine("How many steps does the recipe have? Type response, and then press Enter");
                count = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("------------------------\n");
                List<string> recipeSteps = new List<string>();
                for (int i = 1; i <= count; i++)
                {
                    bool entryAccepted = false;
                    string step = string.Empty;
                    while (entryAccepted == false)
                    {
                        Console.WriteLine("Step: " + i);
                        Console.WriteLine("------------------------\n");
                        Console.WriteLine("Type the step details, and then press Enter");
                        step = Console.ReadLine();
                        entryAccepted = true;
                        if (entryAccepted == false)
                        {
                            Console.WriteLine("Errors!");
                        }
                    }
                    recipeSteps.Add(step);
                    Console.WriteLine("\n");

                }
                Console.WriteLine("Creating recipe, please wait...");
                Console.WriteLine("------------------------\n");
                Recipe newRecipe = new Recipe(recipeName, recipeIngredients, recipeSteps);
                // recipe = newRecipe;
                recipeList.Add(newRecipe);
                Console.WriteLine("Recipe succesfully created.");
                Console.WriteLine("------------------------\n");

            }
            else if (selection == "ssr")
            {
                Console.Write("Enter recipe name:\n");
                string recipeName = Console.ReadLine();
                Recipe? recipe = recipeList.Find(item => item.Name == recipeName);
                if (recipe is null)
                {
                    Console.WriteLine("\nERROR: Recipe " + recipeName + " does not exist, please try again.\n");
                    value = "y";
                    continue;
                }

                do
                {
                    Console.WriteLine("Veiwing Recipe: " + recipe.Name + "\n");

                    Counter calories = new Counter(recipe.CaloriesCounter);
                    if (calories() > 300)
                    {
                        Console.WriteLine("(NB: This recipe has calories above 300!)\n");
                    }

                    Console.Write("Select Option Below:\n");
                    Console.Write("[ dr ] : Display Recipe Information.\n");
                    Console.Write("[ hr ] : Scale Recipe by half.\n");
                    Console.Write("[ ddr ] : Scale Recipe by double.\n");
                    Console.Write("[ tr ] : Scale Recipe by triple.\n");
                    Console.Write("[ rr ] : Reset Recipe.\n");
                    Console.Write("[ cr ] : Clear Recipe.\n");
                    string option = Console.ReadLine();

                    switch (option)
                    {
                        case "ccr":
                            break;
                        case "dr":
                            Console.WriteLine(recipe.ToString());
                            Console.WriteLine("Recipe successfully displayed.");
                            Console.WriteLine("------------------------\n");
                            break;
                        case "hr":
                            recipe.ScaleByFactor(0.5);
                            break;
                        case "ddr":
                            recipe.ScaleByFactor(2);
                            break;
                        case "tr":
                            recipe.ScaleByFactor(3);
                            break;
                        case "cr":
                            var itemToRemove = recipeList.Single(r => r.Name == recipe.Name);
                            recipeList.Remove(itemToRemove);
                            recipe = new Recipe();
                            Console.WriteLine("Recipe successfully cleared/removed.");
                            Console.WriteLine("------------------------\n");
                            break;
                        case "rr":
                            recipe.Reset();
                            Console.WriteLine("Recipe successfully resetted.");
                            Console.WriteLine("------------------------\n");
                            break;
                        default:
                            Console.WriteLine("Wrong input");
                            break;
                    }
                    Console.Write("Do you want to continue(y/n). (Press n to return to main prompt)");
                    level2Value = Console.ReadLine();
                } while (level2Value == "y" || level2Value == "Y");

            }
            else
            {
                Console.WriteLine("Wrong Input");
                value = "y";
            }
            if (level2Value != "n" || level2Value != "N")
            {
                Console.Write("Do you want to continue(y/n):");
                value = Console.ReadLine();
            }
        } while (value == "y" || value == "Y");
        // // Wait for the user to respond before closing.
        Console.Write("Press any key to close the Recipe console app...");
        Console.ReadKey();
    }
}
